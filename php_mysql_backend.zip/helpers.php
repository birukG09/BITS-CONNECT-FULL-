<?php
function json_response($data = [], int $status = 200) {
    http_response_code($status);
    echo json_encode($data);
    exit;
}

function require_login() {
    if (!isset($_SESSION["user_id"])) {
        json_response(["error" => "Unauthorised"], 401);
    }
}

function current_user_id() {
    return $_SESSION["user_id"] ?? null;
}
?>