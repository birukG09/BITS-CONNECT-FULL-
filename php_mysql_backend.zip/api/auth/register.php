<?php
require_once "../../config.php";
require_once "../../helpers.php";

$data = json_decode(file_get_contents("php://input"), true);
$name = trim($data["name"] ?? "");
$email = trim($data["email"] ?? "");
$pass = $data["password"] ?? "";

if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 6) {
    json_response(["error" => "Invalid input"], 422);
}

$stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash) VALUES (?,?,?)");
try {
    $stmt->execute([$name, $email, password_hash($pass, PASSWORD_BCRYPT)]);
    json_response(["message" => "Registered successfully"]);
} catch (PDOException $e) {
    json_response(["error" => "Email already in use"], 409);
}