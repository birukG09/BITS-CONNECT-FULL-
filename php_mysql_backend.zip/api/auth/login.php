<?php
require_once "../../config.php";
require_once "../../helpers.php";

$data = json_decode(file_get_contents("php://input"), true);
$email = trim($data["email"] ?? "");
$pass  = $data["password"] ?? "";

$stmt = $pdo->prepare("SELECT id, password_hash FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user && password_verify($pass, $user["password_hash"])) {
    $_SESSION["user_id"] = $user["id"];
    json_response(["message" => "Login success", "user_id" => $user["id"]]);
}
json_response(["error" => "Invalid credentials"], 401);