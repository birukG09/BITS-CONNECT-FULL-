<?php
require_once "../config.php";
require_once "../helpers.php";
require_login();

$uploadDir = __DIR__ . "/../uploads/";
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

if (!isset($_FILES["file"])) {
    json_response(["error" => "No file sent"], 400);
}
$file = $_FILES["file"];

if ($file["size"] > 10 * 1024 * 1024) {
    json_response(["error" => "File too large"], 413);
}

$allowedExt = ["pdf","png","jpg","jpeg","docx"];
$ext = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
if (!in_array($ext, $allowedExt)) {
    json_response(["error" => "Invalid file type"], 415);
}

$filename = uniqid() . "." . $ext;
move_uploaded_file($file["tmp_name"], $uploadDir . $filename);

json_response(["message" => "Upload successful", "path" => "/uploads/$filename"], 201);